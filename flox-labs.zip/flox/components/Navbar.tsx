'use client';

import { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { usePathname } from 'next/navigation';
import { useAuth } from './AuthProvider';
import { signOut } from '@/lib/supabase';
import { getInitials, canAdmin } from '@/lib/types';

const NAV_LINKS = [
  { href: '/', label: 'Home' },
  { href: '/explore', label: 'Explore' },
  { href: '/members', label: 'Members' },
  { href: '/magazine', label: 'Magazine' },
  { href: '/camps', label: 'Camps' },
];

export default function Navbar() {
  const { profile } = useAuth();
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);

  async function handleSignOut() {
    await signOut();
    window.location.href = '/';
  }

  return (
    <>
      <nav className="sticky top-0 z-50 bg-white/92 backdrop-blur-xl border-b border-border h-[60px]">
        <div className="max-w-[1200px] mx-auto px-6 h-full flex items-center justify-between">
          {/* Brand */}
          <Link href="/" className="flex items-center gap-2.5 no-underline">
            <Image src="/logo.png" alt="Flox Labs" width={32} height={32} className="rounded" />
            <span className="font-semibold text-[15px] tracking-tight text-text-primary">Flox Labs</span>
          </Link>

          {/* Desktop links */}
          <div className="hidden md:flex items-center gap-1">
            {NAV_LINKS.map(link => (
              <Link
                key={link.href}
                href={link.href}
                className={`px-3 py-1.5 text-[13.5px] rounded-md transition-colors no-underline ${
                  pathname === link.href
                    ? 'text-text-primary font-medium'
                    : 'text-text-secondary hover:text-text-primary hover:bg-gray-50'
                }`}
              >
                {link.label}
              </Link>
            ))}
          </div>

          {/* Right side */}
          <div className="flex items-center gap-2">
            {profile ? (
              <div className="relative">
                <button
                  onClick={() => setUserMenuOpen(!userMenuOpen)}
                  className="flex items-center gap-2 px-2 py-1.5 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <div className="w-8 h-8 rounded-full bg-accent-light text-text-primary flex items-center justify-center text-xs font-semibold">
                    {getInitials(profile.name)}
                  </div>
                  <span className="hidden sm:block text-[13px] font-medium">{profile.name.split(' ')[0]}</span>
                  <svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="1.5" className="text-text-tertiary"><polyline points="3,5 6,8 9,5"/></svg>
                </button>

                {userMenuOpen && (
                  <>
                    <div className="fixed inset-0 z-40" onClick={() => setUserMenuOpen(false)} />
                    <div className="animate-slide-down absolute right-0 top-full mt-1 w-52 bg-white border border-border rounded-lg shadow-elevated z-50 py-1.5">
                      <div className="px-3.5 py-2 border-b border-border-light">
                        <p className="text-sm font-medium truncate">{profile.name}</p>
                        <p className="text-xs text-text-tertiary">{profile.role}</p>
                      </div>
                      <Link href="/profile" className="block px-3.5 py-2 text-[13px] text-text-secondary hover:bg-gray-50 no-underline" onClick={() => setUserMenuOpen(false)}>
                        Profile
                      </Link>
                      {canAdmin(profile) && (
                        <Link href="/admin" className="block px-3.5 py-2 text-[13px] text-text-secondary hover:bg-gray-50 no-underline" onClick={() => setUserMenuOpen(false)}>
                          Admin Dashboard
                        </Link>
                      )}
                      <button onClick={handleSignOut} className="w-full text-left px-3.5 py-2 text-[13px] text-red-600 hover:bg-red-50">
                        Sign Out
                      </button>
                    </div>
                  </>
                )}
              </div>
            ) : (
              <Link href="/auth" className="inline-flex items-center px-4 py-2 text-[13px] font-medium bg-accent text-white rounded-lg hover:bg-accent/90 transition-colors no-underline">
                Sign In
              </Link>
            )}

            {/* Mobile toggle */}
            <button
              className="md:hidden p-1 text-text-primary"
              onClick={() => setMobileOpen(!mobileOpen)}
            >
              {mobileOpen ? (
                <svg width="22" height="22" viewBox="0 0 22 22" fill="none" stroke="currentColor" strokeWidth="1.5"><line x1="5" y1="5" x2="17" y2="17"/><line x1="17" y1="5" x2="5" y2="17"/></svg>
              ) : (
                <svg width="22" height="22" viewBox="0 0 22 22" fill="none" stroke="currentColor" strokeWidth="1.5"><line x1="3" y1="6" x2="19" y2="6"/><line x1="3" y1="11" x2="19" y2="11"/><line x1="3" y1="16" x2="19" y2="16"/></svg>
              )}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="md:hidden fixed inset-0 top-[60px] bg-white z-40 p-6 animate-slide-down border-t border-border">
          <div className="flex flex-col gap-1">
            {NAV_LINKS.map(link => (
              <Link
                key={link.href}
                href={link.href}
                className={`py-3 text-[15px] no-underline ${pathname === link.href ? 'text-text-primary font-medium' : 'text-text-secondary'}`}
                onClick={() => setMobileOpen(false)}
              >
                {link.label}
              </Link>
            ))}
            {profile && (
              <>
                <Link href="/profile" className="py-3 text-[15px] text-text-secondary no-underline" onClick={() => setMobileOpen(false)}>Profile</Link>
                {canAdmin(profile) && (
                  <Link href="/admin" className="py-3 text-[15px] text-text-secondary no-underline" onClick={() => setMobileOpen(false)}>Admin</Link>
                )}
              </>
            )}
          </div>
        </div>
      )}
    </>
  );
}

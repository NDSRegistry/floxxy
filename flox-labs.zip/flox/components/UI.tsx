'use client';

import { ReactNode, useState } from 'react';
import Link from 'next/link';
import { getInitials, SDG_LIST } from '@/lib/types';
import type { Project, Profile, SDG } from '@/lib/types';

// ═══════════════════════════════════════════════════════════════
// AVATAR
// ═══════════════════════════════════════════════════════════════

export function Avatar({ name, size = 'md', color }: { name: string; size?: 'sm' | 'md' | 'lg' | 'xl'; color?: string }) {
  const sizes = { sm: 'w-8 h-8 text-[11px]', md: 'w-10 h-10 text-[13px]', lg: 'w-14 h-14 text-[18px]', xl: 'w-20 h-20 text-[24px]' };
  const bg = color ? `${color}18` : '#f0f0f0';
  const fg = color || '#333';
  return (
    <div className={`${sizes[size]} rounded-full flex items-center justify-center font-semibold shrink-0`} style={{ background: bg, color: fg }}>
      {getInitials(name)}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// SDG TAG
// ═══════════════════════════════════════════════════════════════

export function SDGTag({ sdg, small }: { sdg: SDG; small?: boolean }) {
  return (
    <span
      className={`inline-flex items-center rounded text-white font-medium ${small ? 'px-1.5 py-0.5 text-[10px]' : 'px-2 py-0.5 text-[11.5px]'}`}
      style={{ background: sdg.color }}
    >
      {sdg.id}. {sdg.name}
    </span>
  );
}

export function SDGTagById({ id, small }: { id: number; small?: boolean }) {
  const sdg = SDG_LIST.find(s => s.id === id);
  if (!sdg) return null;
  return <SDGTag sdg={sdg} small={small} />;
}

// ═══════════════════════════════════════════════════════════════
// SDG PICKER (for forms)
// ═══════════════════════════════════════════════════════════════

export function SDGPicker({ selected, onChange }: { selected: number[]; onChange: (ids: number[]) => void }) {
  return (
    <div className="flex flex-wrap gap-1.5">
      {SDG_LIST.map(s => {
        const active = selected.includes(s.id);
        return (
          <button
            key={s.id}
            type="button"
            onClick={() => onChange(active ? selected.filter(x => x !== s.id) : [...selected, s.id])}
            className="px-2 py-1 text-[11px] rounded font-medium border transition-colors"
            style={{
              borderColor: active ? s.color : '#e8e8e8',
              background: active ? s.color + '15' : 'white',
              color: active ? s.color : '#666',
            }}
          >
            {s.id}. {s.name}
          </button>
        );
      })}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// MODAL
// ═══════════════════════════════════════════════════════════════

export function Modal({ title, onClose, children, footer }: { title: string; onClose: () => void; children: ReactNode; footer?: ReactNode }) {
  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[200] flex items-center justify-center p-5" onClick={onClose}>
      <div className="bg-white rounded-xl max-w-[520px] w-full max-h-[85vh] overflow-y-auto shadow-elevated animate-slide-up" onClick={e => e.stopPropagation()}>
        <div className="px-6 pt-5 flex justify-between items-center">
          <h3 className="text-[17px] font-semibold">{title}</h3>
          <button onClick={onClose} className="p-1 text-text-tertiary hover:text-text-primary transition-colors">
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none" stroke="currentColor" strokeWidth="1.5"><line x1="4" y1="4" x2="14" y2="14"/><line x1="14" y1="4" x2="4" y2="14"/></svg>
          </button>
        </div>
        <div className="px-6 py-5">{children}</div>
        {footer && <div className="px-6 pb-5 flex justify-end gap-2">{footer}</div>}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// STATUS BADGE
// ═══════════════════════════════════════════════════════════════

export function StatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    'Active': 'bg-emerald-50 text-emerald-600',
    'In Development': 'bg-blue-50 text-blue-600',
    'Archived': 'bg-gray-100 text-gray-500',
    'Open': 'bg-emerald-50 text-emerald-600',
    'Full': 'bg-red-50 text-red-500',
  };
  return (
    <span className={`inline-flex items-center px-2 py-0.5 text-[11px] font-semibold rounded-full uppercase tracking-wider ${styles[status] || 'bg-gray-100 text-gray-500'}`}>
      {status}
    </span>
  );
}

// ═══════════════════════════════════════════════════════════════
// ROLE TAG
// ═══════════════════════════════════════════════════════════════

export function RoleTag({ role }: { role: string }) {
  const colors: Record<string, string> = {
    'Lab Director': '#1a2332',
    'Lab Manager': '#2563eb',
    'Lab Staff': '#16a34a',
    'Genius': '#9333ea',
  };
  const c = colors[role] || '#666';
  return (
    <span className="inline-flex items-center px-2 py-0.5 text-[11.5px] font-medium rounded border" style={{ borderColor: c + '30', background: c + '08', color: c }}>
      {role}
    </span>
  );
}

// ═══════════════════════════════════════════════════════════════
// PROJECT CARD
// ═══════════════════════════════════════════════════════════════

function ProjectPattern({ sdgs }: { sdgs: SDG[] }) {
  const c1 = sdgs[0]?.color || '#e5e5e5';
  const c2 = sdgs[1]?.color || c1;
  const uid = sdgs.map(s => s.id).join('-');
  return (
    <svg className="absolute inset-0 opacity-30" width="100%" height="100%" viewBox="0 0 400 160" preserveAspectRatio="none">
      <defs>
        <linearGradient id={`pg-${uid}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor={c1} stopOpacity="0.15" />
          <stop offset="100%" stopColor={c2} stopOpacity="0.08" />
        </linearGradient>
      </defs>
      <rect width="400" height="160" fill={`url(#pg-${uid})`} />
      <circle cx="320" cy="30" r="80" fill={c1} opacity="0.07" />
      <circle cx="80" cy="130" r="60" fill={c2} opacity="0.05" />
    </svg>
  );
}

export function ProjectCard({ project }: { project: Project }) {
  const sdgs = project.sdgs || [];
  return (
    <Link href={`/explore/${project.id}`} className="no-underline">
      <div className="bg-white border border-border rounded-xl overflow-hidden transition-all hover:shadow-card hover:border-gray-200 group">
        <div className="h-40 bg-[#fafafa] flex items-center justify-center relative overflow-hidden">
          <ProjectPattern sdgs={sdgs} />
          <span className="font-display text-3xl text-text-tertiary relative z-10 opacity-40 group-hover:opacity-60 transition-opacity">
            {project.title.charAt(0)}
          </span>
        </div>
        <div className="p-5">
          <div className="flex justify-between items-start gap-2">
            <h3 className="text-[15px] font-semibold tracking-tight text-text-primary">{project.title}</h3>
            <StatusBadge status={project.status} />
          </div>
          <p className="text-[13.5px] text-text-secondary leading-relaxed mt-1.5 line-clamp-2">
            {project.description}
          </p>
          <div className="flex gap-1 flex-wrap mt-3">
            {sdgs.map(s => <SDGTag key={s.id} sdg={s} small />)}
          </div>
          {project.creator && (
            <div className="flex items-center gap-2 mt-3.5 pt-3.5 border-t border-border-light">
              <Avatar name={project.creator.name} size="sm" />
              <span className="text-[13px] text-text-secondary">{project.creator.name}</span>
            </div>
          )}
        </div>
      </div>
    </Link>
  );
}

// ═══════════════════════════════════════════════════════════════
// EMPTY STATE
// ═══════════════════════════════════════════════════════════════

export function EmptyState({ icon, message }: { icon: ReactNode; message: string }) {
  return (
    <div className="text-center py-16">
      <div className="w-12 h-12 rounded-xl bg-gray-50 inline-flex items-center justify-center mb-4 text-text-tertiary">
        {icon}
      </div>
      <p className="text-sm text-text-secondary">{message}</p>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// SECTION HEADER
// ═══════════════════════════════════════════════════════════════

export function SectionHeader({ label, title, subtitle }: { label?: string; title: string; subtitle?: string }) {
  return (
    <div>
      {label && <p className="text-[11.5px] font-semibold uppercase tracking-widest text-text-tertiary mb-3">{label}</p>}
      <h1 className="font-display text-4xl tracking-tight">{title}</h1>
      {subtitle && <p className="text-[15px] text-text-secondary mt-2 leading-relaxed max-w-lg">{subtitle}</p>}
    </div>
  );
}

# Flox Labs

Innovation platform where users create projects connected to the UN Sustainable Development Goals. Built with Next.js 14, Tailwind CSS, and Supabase.

## Setup (5 minutes)

### 1. Install

```bash
npm install
```

### 2. Supabase

1. Create a free project at [supabase.com](https://supabase.com)
2. Go to **SQL Editor** → paste and run everything in `supabase/schema.sql`
3. Go to **Settings → API** → copy your URL and anon key
4. Create `.env.local`:

```
NEXT_PUBLIC_SUPABASE_URL=https://xxxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUz...
```

### 3. Run

```bash
npm run dev
```

Open http://localhost:3000

### 4. First Admin

1. Sign up through the app
2. In Supabase → **Table Editor → profiles**
3. Set your row: `is_admin = true`, `role = Lab Director`
4. Refresh the app — you now have full admin access

## Permissions

| Action | Genius | Lab Staff | Lab Manager | Lab Director | Admin |
|--------|--------|-----------|-------------|--------------|-------|
| Create projects | ✅ | ✅ | ✅ | ✅ | ✅ |
| Create posts/magazine | ❌ | ✅ | ✅ | ✅ | ✅ |
| Create camps/events | ❌ | ✅ | ✅ | ✅ | ✅ |
| Promote/demote users | ❌ | ❌ | ❌ | ❌ | ✅ |
| Delete any content | ❌ | ❌ | ❌ | ❌ | ✅ |
| Admin dashboard | ❌ | ❌ | ❌ | ❌ | ✅ |

## Pages

- `/` — Home (hero, featured projects, SDGs, framework)
- `/explore` — Browse all projects with search + SDG filter
- `/explore/[id]` — Project detail
- `/members` — All users grouped by rank
- `/magazine` — Blog/newsletter (Lab Staff+ can create)
- `/camps` — Events (Lab Staff+ can create, users can register)
- `/profile` — User dashboard + project creation
- `/admin` — Admin panel (users, projects, posts, camps)
- `/auth` — Login / signup

## Deploy to Vercel

```bash
npx vercel
```

Add env vars in Vercel dashboard → Settings → Environment Variables.

---

© 2026 Flox Labs

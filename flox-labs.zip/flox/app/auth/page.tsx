'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Image from 'next/image';
import { signIn, signUp } from '@/lib/supabase';
import { useAuth } from '@/components/AuthProvider';
import { useToast } from '@/components/Toast';

export default function AuthPage() {
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const router = useRouter();
  const { refresh } = useAuth();
  const toast = useToast();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setLoading(true);

    if (mode === 'login') {
      const { error: err } = await signIn(email, password);
      if (err) {
        setError(err.message);
        setLoading(false);
        return;
      }
      toast.show('Welcome back');
    } else {
      if (!name.trim()) { setError('Name is required'); setLoading(false); return; }
      const { error: err } = await signUp(email, password, name.trim());
      if (err) {
        setError(err.message);
        setLoading(false);
        return;
      }
      toast.show('Account created! Welcome to Flox Labs');
    }

    await refresh();
    setLoading(false);
    router.push('/');
  }

  return (
    <div className="min-h-[calc(100vh-60px)] flex items-center justify-center animate-in">
      <div className="w-full max-w-[400px] px-6">
        <div className="text-center mb-8">
          <Image src="/logo.png" alt="Flox Labs" width={48} height={48} className="mx-auto rounded-lg mb-4" />
          <h1 className="font-display text-[28px]">
            {mode === 'login' ? 'Welcome back' : 'Join Flox Labs'}
          </h1>
          <p className="text-[14px] text-text-secondary mt-1.5">
            {mode === 'login' ? 'Sign in to your account' : 'Create your account to start building'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {mode === 'signup' && (
            <div>
              <label className="block text-[12.5px] font-medium mb-1.5">Full Name</label>
              <input
                type="text"
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="Your name"
                className="w-full px-3 py-2.5 text-[14px] border border-border rounded-lg outline-none focus:border-gray-400 transition-colors"
              />
            </div>
          )}
          <div>
            <label className="block text-[12.5px] font-medium mb-1.5">Email</label>
            <input
              type="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="w-full px-3 py-2.5 text-[14px] border border-border rounded-lg outline-none focus:border-gray-400 transition-colors"
              required
            />
          </div>
          <div>
            <label className="block text-[12.5px] font-medium mb-1.5">Password</label>
            <input
              type="password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full px-3 py-2.5 text-[14px] border border-border rounded-lg outline-none focus:border-gray-400 transition-colors"
              required
              minLength={6}
            />
          </div>

          {error && <p className="text-[13px] text-red-600">{error}</p>}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-2.5 text-[14px] font-medium bg-accent text-white rounded-lg hover:bg-accent/90 transition-colors disabled:opacity-50"
          >
            {loading ? 'Loading...' : mode === 'login' ? 'Sign In' : 'Create Account'}
          </button>
        </form>

        <p className="text-center text-[13px] text-text-secondary mt-5">
          {mode === 'login' ? "Don't have an account?" : 'Already have an account?'}
          {' '}
          <button
            className="text-text-primary font-medium hover:underline"
            onClick={() => { setMode(mode === 'login' ? 'signup' : 'login'); setError(''); }}
          >
            {mode === 'login' ? 'Sign Up' : 'Sign In'}
          </button>
        </p>
      </div>
    </div>
  );
}

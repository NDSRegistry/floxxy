export type UserRole = 'Genius' | 'Lab Staff' | 'Lab Manager' | 'Lab Director';

export const ROLE_HIERARCHY: UserRole[] = ['Genius', 'Lab Staff', 'Lab Manager', 'Lab Director'];

export interface Profile {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  bio: string;
  avatar_url: string | null;
  is_admin: boolean;
  created_at: string;
  updated_at: string;
}

export interface SDG {
  id: number;
  name: string;
  color: string;
}

export interface Project {
  id: string;
  title: string;
  description: string;
  creator_id: string;
  status: 'Active' | 'In Development' | 'Archived';
  image_url: string | null;
  media_link: string | null;
  created_at: string;
  updated_at: string;
  sdgs?: SDG[];
  creator?: Profile;
}

export interface Post {
  id: string;
  title: string;
  content: string;
  tag: string;
  author_id: string;
  published: boolean;
  created_at: string;
  updated_at: string;
  author?: Profile;
}

export interface Camp {
  id: string;
  title: string;
  description: string;
  date_range: string;
  location: string;
  total_spots: number;
  registered_count: number;
  created_by: string | null;
  created_at: string;
  sdgs?: SDG[];
}

export const SDG_LIST: SDG[] = [
  { id: 1, name: 'No Poverty', color: '#E5243B' },
  { id: 2, name: 'Zero Hunger', color: '#DDA63A' },
  { id: 3, name: 'Good Health', color: '#4C9F38' },
  { id: 4, name: 'Quality Education', color: '#C5192D' },
  { id: 5, name: 'Gender Equality', color: '#FF3A21' },
  { id: 6, name: 'Clean Water', color: '#26BDE2' },
  { id: 7, name: 'Clean Energy', color: '#FCC30B' },
  { id: 8, name: 'Decent Work', color: '#A21942' },
  { id: 9, name: 'Industry & Innovation', color: '#FD6925' },
  { id: 10, name: 'Reduced Inequalities', color: '#DD1367' },
  { id: 11, name: 'Sustainable Cities', color: '#FD9D24' },
  { id: 12, name: 'Responsible Consumption', color: '#BF8B2E' },
  { id: 13, name: 'Climate Action', color: '#3F7E44' },
  { id: 14, name: 'Life Below Water', color: '#0A97D9' },
  { id: 15, name: 'Life on Land', color: '#56C02B' },
  { id: 16, name: 'Peace & Justice', color: '#00689D' },
  { id: 17, name: 'Partnerships', color: '#19486A' },
];

// Permission helpers
export function canManageContent(profile: Profile | null): boolean {
  if (!profile) return false;
  return profile.is_admin || ['Lab Staff', 'Lab Manager', 'Lab Director'].includes(profile.role);
}

export function canAdmin(profile: Profile | null): boolean {
  if (!profile) return false;
  return profile.is_admin;
}

export function getInitials(name: string): string {
  return name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2);
}

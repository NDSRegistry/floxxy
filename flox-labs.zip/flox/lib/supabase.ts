import { createClient } from '@supabase/supabase-js';
import type { Profile, Project, Post, Camp, UserRole } from './types';

const url = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

export const supabase = createClient(url, key);

// ═══════════════════════════════════════════════════════════════
// AUTH
// ═══════════════════════════════════════════════════════════════

export async function signUp(email: string, password: string, name: string) {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: { data: { name } },
  });
  return { data, error };
}

export async function signIn(email: string, password: string) {
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  return { data, error };
}

export async function signOut() {
  return supabase.auth.signOut();
}

export async function getSession() {
  const { data: { session } } = await supabase.auth.getSession();
  return session;
}

export async function getCurrentProfile(): Promise<Profile | null> {
  const session = await getSession();
  if (!session?.user) return null;
  const { data } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', session.user.id)
    .single();
  return data;
}

// ═══════════════════════════════════════════════════════════════
// PROFILES
// ═══════════════════════════════════════════════════════════════

export async function getProfiles(): Promise<Profile[]> {
  const { data } = await supabase
    .from('profiles')
    .select('*')
    .order('created_at', { ascending: true });
  return data || [];
}

export async function getProfile(id: string): Promise<Profile | null> {
  const { data } = await supabase.from('profiles').select('*').eq('id', id).single();
  return data;
}

export async function updateProfile(id: string, updates: Partial<Profile>) {
  const { data, error } = await supabase.from('profiles').update(updates).eq('id', id).select().single();
  return { data, error };
}

export async function promoteUser(id: string, newRole: UserRole) {
  return updateProfile(id, { role: newRole } as any);
}

// ═══════════════════════════════════════════════════════════════
// PROJECTS
// ═══════════════════════════════════════════════════════════════

export async function getProjects(): Promise<Project[]> {
  const { data: projects } = await supabase
    .from('projects')
    .select('*, creator:profiles!creator_id(*)')
    .order('created_at', { ascending: false });

  if (!projects || projects.length === 0) return [];

  const ids = projects.map(p => p.id);
  const { data: psdgs } = await supabase
    .from('project_sdgs')
    .select('project_id, sdg:sdgs(*)')
    .in('project_id', ids);

  return projects.map(p => ({
    ...p,
    sdgs: (psdgs || []).filter(ps => ps.project_id === p.id).map(ps => ps.sdg),
  }));
}

export async function getProject(id: string): Promise<Project | null> {
  const { data: project } = await supabase
    .from('projects')
    .select('*, creator:profiles!creator_id(*)')
    .eq('id', id)
    .single();

  if (!project) return null;

  const { data: psdgs } = await supabase
    .from('project_sdgs')
    .select('sdg:sdgs(*)')
    .eq('project_id', id);

  return { ...project, sdgs: (psdgs || []).map(ps => ps.sdg) };
}

export async function createProject(
  title: string,
  description: string,
  creatorId: string,
  sdgIds: number[],
  status: string = 'In Development'
) {
  const { data: project, error } = await supabase
    .from('projects')
    .insert({ title, description, creator_id: creatorId, status })
    .select()
    .single();

  if (error || !project) return { data: null, error };

  if (sdgIds.length > 0) {
    await supabase.from('project_sdgs').insert(
      sdgIds.map(sid => ({ project_id: project.id, sdg_id: sid }))
    );
  }
  return { data: project, error: null };
}

export async function updateProject(id: string, updates: Partial<Project>) {
  return supabase.from('projects').update(updates).eq('id', id).select().single();
}

export async function deleteProject(id: string) {
  await supabase.from('project_sdgs').delete().eq('project_id', id);
  return supabase.from('projects').delete().eq('id', id);
}

// ═══════════════════════════════════════════════════════════════
// POSTS (Magazine) — Lab Staff+ only
// ═══════════════════════════════════════════════════════════════

export async function getPosts(): Promise<Post[]> {
  const { data } = await supabase
    .from('posts')
    .select('*, author:profiles!author_id(*)')
    .eq('published', true)
    .order('created_at', { ascending: false });
  return data || [];
}

export async function getPost(id: string): Promise<Post | null> {
  const { data } = await supabase
    .from('posts')
    .select('*, author:profiles!author_id(*)')
    .eq('id', id)
    .single();
  return data;
}

export async function createPost(title: string, content: string, tag: string, authorId: string) {
  return supabase.from('posts').insert({ title, content, tag, author_id: authorId }).select().single();
}

export async function deletePost(id: string) {
  return supabase.from('posts').delete().eq('id', id);
}

// ═══════════════════════════════════════════════════════════════
// CAMPS — Lab Staff+ only
// ═══════════════════════════════════════════════════════════════

export async function getCamps(): Promise<Camp[]> {
  const { data: camps } = await supabase
    .from('camps')
    .select('*')
    .order('created_at', { ascending: false });

  if (!camps || camps.length === 0) return [];

  const ids = camps.map(c => c.id);
  const { data: csdgs } = await supabase
    .from('camp_sdgs')
    .select('camp_id, sdg:sdgs(*)')
    .in('camp_id', ids);

  return camps.map(c => ({
    ...c,
    sdgs: (csdgs || []).filter(cs => cs.camp_id === c.id).map(cs => cs.sdg),
  }));
}

export async function createCamp(
  title: string,
  description: string,
  dateRange: string,
  location: string,
  totalSpots: number,
  createdBy: string,
  sdgIds: number[]
) {
  const { data: camp, error } = await supabase
    .from('camps')
    .insert({ title, description, date_range: dateRange, location, total_spots: totalSpots, created_by: createdBy })
    .select()
    .single();

  if (error || !camp) return { data: null, error };

  if (sdgIds.length > 0) {
    await supabase.from('camp_sdgs').insert(
      sdgIds.map(sid => ({ camp_id: camp.id, sdg_id: sid }))
    );
  }
  return { data: camp, error: null };
}

export async function deleteCamp(id: string) {
  await supabase.from('camp_sdgs').delete().eq('camp_id', id);
  await supabase.from('camp_registrations').delete().eq('camp_id', id);
  return supabase.from('camps').delete().eq('id', id);
}

export async function registerForCamp(campId: string, userId: string) {
  return supabase.from('camp_registrations').insert({ camp_id: campId, user_id: userId });
}

export async function unregisterFromCamp(campId: string, userId: string) {
  return supabase.from('camp_registrations').delete().eq('camp_id', campId).eq('user_id', userId);
}

export async function getUserCampRegistrations(userId: string): Promise<string[]> {
  const { data } = await supabase
    .from('camp_registrations')
    .select('camp_id')
    .eq('user_id', userId);
  return (data || []).map(r => r.camp_id);
}

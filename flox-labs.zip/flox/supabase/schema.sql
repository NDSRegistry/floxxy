-- ============================================================
-- FLOX LABS — Complete Production Database Schema
-- Run this in Supabase SQL Editor (Settings → SQL Editor)
-- ============================================================

-- Enable extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ── Custom types ──
DO $$ BEGIN
  CREATE TYPE user_role AS ENUM ('Genius', 'Lab Staff', 'Lab Manager', 'Lab Director');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

-- ══════════════════════════════════════════════════════════════
-- TABLES
-- ══════════════════════════════════════════════════════════════

-- ── Profiles ──
CREATE TABLE IF NOT EXISTS profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  role user_role NOT NULL DEFAULT 'Genius',
  bio TEXT DEFAULT '',
  avatar_url TEXT,
  is_admin BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── SDGs ──
CREATE TABLE IF NOT EXISTS sdgs (
  id INT PRIMARY KEY,
  name TEXT NOT NULL,
  color TEXT NOT NULL
);

-- ── Projects ──
CREATE TABLE IF NOT EXISTS projects (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  creator_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'In Development' CHECK (status IN ('Active', 'In Development', 'Archived')),
  image_url TEXT,
  media_link TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── Project ↔ SDG junction ──
CREATE TABLE IF NOT EXISTS project_sdgs (
  project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
  sdg_id INT REFERENCES sdgs(id) ON DELETE CASCADE,
  PRIMARY KEY (project_id, sdg_id)
);

-- ── Posts (Magazine / Newsletter) ──
-- Only admins and Lab Staff+ can create these (enforced in RLS)
CREATE TABLE IF NOT EXISTS posts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  tag TEXT NOT NULL DEFAULT 'Announcement' CHECK (tag IN ('Announcement', 'Project Spotlight', 'Events', 'Research', 'Newsletter')),
  author_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  published BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── Camps / Events ──
-- Only admins and Lab Staff+ can create these (enforced in RLS)
CREATE TABLE IF NOT EXISTS camps (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  date_range TEXT NOT NULL,
  location TEXT NOT NULL,
  total_spots INT NOT NULL DEFAULT 40,
  registered_count INT NOT NULL DEFAULT 0,
  created_by UUID REFERENCES profiles(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── Camp ↔ SDG junction ──
CREATE TABLE IF NOT EXISTS camp_sdgs (
  camp_id UUID REFERENCES camps(id) ON DELETE CASCADE,
  sdg_id INT REFERENCES sdgs(id) ON DELETE CASCADE,
  PRIMARY KEY (camp_id, sdg_id)
);

-- ── Camp registrations ──
CREATE TABLE IF NOT EXISTS camp_registrations (
  camp_id UUID REFERENCES camps(id) ON DELETE CASCADE,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  registered_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (camp_id, user_id)
);

-- ══════════════════════════════════════════════════════════════
-- INDEXES
-- ══════════════════════════════════════════════════════════════

CREATE INDEX IF NOT EXISTS idx_projects_creator ON projects(creator_id);
CREATE INDEX IF NOT EXISTS idx_projects_status ON projects(status);
CREATE INDEX IF NOT EXISTS idx_projects_created ON projects(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_posts_author ON posts(author_id);
CREATE INDEX IF NOT EXISTS idx_posts_tag ON posts(tag);
CREATE INDEX IF NOT EXISTS idx_posts_created ON posts(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_project_sdgs_project ON project_sdgs(project_id);
CREATE INDEX IF NOT EXISTS idx_project_sdgs_sdg ON project_sdgs(sdg_id);
CREATE INDEX IF NOT EXISTS idx_camp_sdgs_camp ON camp_sdgs(camp_id);

-- ══════════════════════════════════════════════════════════════
-- FUNCTIONS
-- ══════════════════════════════════════════════════════════════

-- Auto-update updated_at
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Check if user is admin or Lab Staff+
CREATE OR REPLACE FUNCTION is_staff_or_above(user_id UUID)
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM profiles
    WHERE id = user_id
    AND (is_admin = true OR role IN ('Lab Staff', 'Lab Manager', 'Lab Director'))
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Check if user is admin
CREATE OR REPLACE FUNCTION is_admin(user_id UUID)
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM profiles WHERE id = user_id AND is_admin = true
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Handle new user signup → auto-create profile
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO profiles (id, name, email, role, is_admin)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'name', split_part(NEW.email, '@', 1)),
    NEW.email,
    'Genius',
    FALSE
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Update camp registered_count when someone registers
CREATE OR REPLACE FUNCTION update_camp_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE camps SET registered_count = registered_count + 1 WHERE id = NEW.camp_id;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE camps SET registered_count = registered_count - 1 WHERE id = OLD.camp_id;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ══════════════════════════════════════════════════════════════
-- TRIGGERS
-- ══════════════════════════════════════════════════════════════

DROP TRIGGER IF EXISTS profiles_updated_at ON profiles;
CREATE TRIGGER profiles_updated_at BEFORE UPDATE ON profiles FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS projects_updated_at ON projects;
CREATE TRIGGER projects_updated_at BEFORE UPDATE ON projects FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS posts_updated_at ON posts;
CREATE TRIGGER posts_updated_at BEFORE UPDATE ON posts FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

DROP TRIGGER IF EXISTS on_camp_register ON camp_registrations;
CREATE TRIGGER on_camp_register
  AFTER INSERT OR DELETE ON camp_registrations
  FOR EACH ROW EXECUTE FUNCTION update_camp_count();

-- ══════════════════════════════════════════════════════════════
-- ROW LEVEL SECURITY
-- ══════════════════════════════════════════════════════════════

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE project_sdgs ENABLE ROW LEVEL SECURITY;
ALTER TABLE posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE camps ENABLE ROW LEVEL SECURITY;
ALTER TABLE camp_sdgs ENABLE ROW LEVEL SECURITY;
ALTER TABLE camp_registrations ENABLE ROW LEVEL SECURITY;
ALTER TABLE sdgs ENABLE ROW LEVEL SECURITY;

-- SDGs: public read
CREATE POLICY "SDGs readable by all" ON sdgs FOR SELECT USING (true);

-- Profiles
CREATE POLICY "Profiles readable by all" ON profiles FOR SELECT USING (true);
CREATE POLICY "Users can insert own profile" ON profiles FOR INSERT WITH CHECK (auth.uid() = id);
CREATE POLICY "Users can update own profile" ON profiles FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "Admins can update any profile" ON profiles FOR UPDATE USING (is_admin(auth.uid()));

-- Projects
CREATE POLICY "Projects readable by all" ON projects FOR SELECT USING (true);
CREATE POLICY "Auth users can create projects" ON projects FOR INSERT WITH CHECK (auth.uid() = creator_id);
CREATE POLICY "Creators can update own projects" ON projects FOR UPDATE USING (auth.uid() = creator_id);
CREATE POLICY "Admins can update any project" ON projects FOR UPDATE USING (is_admin(auth.uid()));
CREATE POLICY "Creators can delete own projects" ON projects FOR DELETE USING (auth.uid() = creator_id);
CREATE POLICY "Admins can delete any project" ON projects FOR DELETE USING (is_admin(auth.uid()));

-- Project SDGs
CREATE POLICY "Project SDGs readable by all" ON project_sdgs FOR SELECT USING (true);
CREATE POLICY "Auth users can add project SDGs" ON project_sdgs FOR INSERT WITH CHECK (
  EXISTS (SELECT 1 FROM projects WHERE id = project_id AND creator_id = auth.uid())
);
CREATE POLICY "Creators can remove project SDGs" ON project_sdgs FOR DELETE USING (
  EXISTS (SELECT 1 FROM projects WHERE id = project_id AND creator_id = auth.uid())
);

-- Posts: only Lab Staff+ and admins can create/edit/delete
CREATE POLICY "Published posts readable by all" ON posts FOR SELECT USING (published = true);
CREATE POLICY "Staff+ can create posts" ON posts FOR INSERT WITH CHECK (is_staff_or_above(auth.uid()));
CREATE POLICY "Staff+ can update own posts" ON posts FOR UPDATE USING (
  author_id = auth.uid() AND is_staff_or_above(auth.uid())
);
CREATE POLICY "Admins can update any post" ON posts FOR UPDATE USING (is_admin(auth.uid()));
CREATE POLICY "Admins can delete posts" ON posts FOR DELETE USING (is_admin(auth.uid()));
CREATE POLICY "Authors can delete own posts" ON posts FOR DELETE USING (
  author_id = auth.uid() AND is_staff_or_above(auth.uid())
);

-- Camps: only Lab Staff+ and admins can create
CREATE POLICY "Camps readable by all" ON camps FOR SELECT USING (true);
CREATE POLICY "Staff+ can create camps" ON camps FOR INSERT WITH CHECK (is_staff_or_above(auth.uid()));
CREATE POLICY "Staff+ can update camps" ON camps FOR UPDATE USING (is_staff_or_above(auth.uid()));
CREATE POLICY "Admins can delete camps" ON camps FOR DELETE USING (is_admin(auth.uid()));

-- Camp SDGs
CREATE POLICY "Camp SDGs readable by all" ON camp_sdgs FOR SELECT USING (true);
CREATE POLICY "Staff+ can manage camp SDGs" ON camp_sdgs FOR INSERT WITH CHECK (is_staff_or_above(auth.uid()));
CREATE POLICY "Staff+ can remove camp SDGs" ON camp_sdgs FOR DELETE USING (is_staff_or_above(auth.uid()));

-- Camp registrations
CREATE POLICY "Registrations readable by all" ON camp_registrations FOR SELECT USING (true);
CREATE POLICY "Users can register themselves" ON camp_registrations FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can unregister themselves" ON camp_registrations FOR DELETE USING (auth.uid() = user_id);

-- ══════════════════════════════════════════════════════════════
-- SEED DATA
-- ══════════════════════════════════════════════════════════════

INSERT INTO sdgs (id, name, color) VALUES
  (1, 'No Poverty', '#E5243B'),
  (2, 'Zero Hunger', '#DDA63A'),
  (3, 'Good Health', '#4C9F38'),
  (4, 'Quality Education', '#C5192D'),
  (5, 'Gender Equality', '#FF3A21'),
  (6, 'Clean Water', '#26BDE2'),
  (7, 'Clean Energy', '#FCC30B'),
  (8, 'Decent Work', '#A21942'),
  (9, 'Industry & Innovation', '#FD6925'),
  (10, 'Reduced Inequalities', '#DD1367'),
  (11, 'Sustainable Cities', '#FD9D24'),
  (12, 'Responsible Consumption', '#BF8B2E'),
  (13, 'Climate Action', '#3F7E44'),
  (14, 'Life Below Water', '#0A97D9'),
  (15, 'Life on Land', '#56C02B'),
  (16, 'Peace & Justice', '#00689D'),
  (17, 'Partnerships', '#19486A')
ON CONFLICT (id) DO NOTHING;
